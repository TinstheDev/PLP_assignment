# Define the enhanced Superhero class
class Superhero:
    def __init__(self, name, superpower, alter_ego, city, strength, health, weapon=None):
        self.name = name  # The superhero's name
        self.superpower = superpower  # The superhero's superpower
        self.alter_ego = alter_ego  # The superhero's alter ego
        self.city = city  # The city they protect
        self.strength = strength  # Superhero's strength level
        self.health = health  # Superhero's health
        self.weapon = weapon  # Optional weapon (e.g., sword, shield, etc.)

    # Method to display superhero details
    def display_details(self):
        print(f"Superhero Name: {self.name}")
        print(f"Alter Ego: {self.alter_ego}")
        print(f"Superpower: {self.superpower}")
        print(f"City: {self.city}")
        print(f"Strength: {self.strength}")
        print(f"Health: {self.health}")
        if self.weapon:
            print(f"Weapon: {self.weapon}")
        else:
            print("Weapon: None")

    # Method to simulate training, which increases strength
    def train(self):
        self.strength += 10
        print(f"{self.name} trained hard and gained strength! New strength: {self.strength}")

    # Method to simulate healing, which restores health
    def heal(self):
        self.health += 20
        print(f"{self.name} healed themselves. Health restored! New health: {self.health}")

    # Method to simulate a fight, which decreases health
    def fight(self):
        if self.health > 0:
            self.health -= 30
            print(f"{self.name} fought a villain and lost some health! New health: {self.health}")
        else:
            print(f"{self.name} is too weak to fight!")

    # Method to simulate rescuing someone, which increases health
    def rescue(self):
        self.health += 15
        print(f"{self.name} rescued a civilian! Health restored. New health: {self.health}")

    # Method to perform an action: fight crime
    def fight_crime(self):
        print(f"{self.name} is fighting crime using their {self.superpower}!")


# Creating unique superhero objects with the constructor

# Superhero 1: Spider-Man
spider_man = Superhero(
    name="Spider-Man", 
    superpower="Web-Slinging", 
    alter_ego="Peter Parker", 
    city="New York", 
    strength=100, 
    health=80
)

# Superhero 2: Iron Man
iron_man = Superhero(
    name="Iron Man", 
    superpower="Powered Armor", 
    alter_ego="Tony Stark", 
    city="New York", 
    strength=150, 
    health=90, 
    weapon="Repulsor Rays"
)

# Superhero 3: Wonder Woman
wonder_woman = Superhero(
    name="Wonder Woman", 
    superpower="Super Strength and Agility", 
    alter_ego="Diana Prince", 
    city="Metropolis", 
    strength=120, 
    health=100, 
    weapon="Lasso of Truth"
)

# Display details for each superhero
spider_man.display_details()
iron_man.display_details()
wonder_woman.display_details()

# Perform some actions
spider_man.train()
iron_man.fight()
wonder_woman.rescue()

# Fight crime using each superhero's powers
spider_man.fight_crime()
iron_man.fight_crime()
wonder_woman.fight_crime()
