# Define the enhanced Superhero class
class Superhero:
    def __init__(self, name, superpower, alter_ego, city, strength, health, weapon=None):
        self.name = name  # The superhero's name
        self.superpower = superpower  # The superhero's superpower
        self.alter_ego = alter_ego  # The superhero's alter ego
        self.city = city  # The city they protect
        self.strength = strength  # Superhero's strength level
        self.health = health  # Superhero's health
        self.weapon = weapon  # Optional weapon (e.g., sword, shield, etc.)

    # Method to display superhero details
    def display_details(self):
        print(f"Superhero Name: {self.name}")
        print(f"Alter Ego: {self.alter_ego}")
        print(f"Superpower: {self.superpower}")
        print(f"City: {self.city}")
        print(f"Strength: {self.strength}")
        print(f"Health: {self.health}")
        if self.weapon:
            print(f"Weapon: {self.weapon}")
        else:
            print("Weapon: None")

    # Method to simulate training, which increases strength
    def train(self):
        self.strength += 10
        print(f"{self.name} trained hard and gained strength! New strength: {self.strength}")

    # Method to simulate healing, which restores health
    def heal(self):
        self.health += 20
        print(f"{self.name} healed themselves. Health restored! New health: {self.health}")

    # Method to simulate a fight, which decreases health
    def fight(self):
        if self.health > 0:
            self.health -= 30
            print(f"{self.name} fought a villain and lost some health! New health: {self.health}")
        else:
            print(f"{self.name} is too weak to fight!")

    # Method to simulate rescuing someone, which increases health
    def rescue(self):
        self.health += 15
        print(f"{self.name} rescued a civilian! Health restored. New health: {self.health}")

    # Method to perform an action: fight crime
    def fight_crime(self):
        print(f"{self.name} is fighting crime using their {self.superpower}!")

# Create an instance of the Superhero class
hero = Superhero("Spider-Man", "Web-Slinging", "Peter Parker", "New York", 100, 80)

# Display superhero details
hero.display_details()

# Hero trains, heals, fights, rescues, and fights crime
hero.train()
hero.heal()
hero.fight()
hero.rescue()
hero.fight_crime()
