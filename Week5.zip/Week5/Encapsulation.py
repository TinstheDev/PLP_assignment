# Parent class: Hero
class Hero:
    def __init__(self, name, alter_ego, city, strength, health):
        self.name = name  # The hero's name
        self.alter_ego = alter_ego  # The hero's alter ego
        self.city = city  # The city they protect
        self.__strength = strength  # Private attribute: Hero's strength (encapsulated)
        self.__health = health  # Private attribute: Hero's health (encapsulated)

    # Getter method for strength (encapsulation)
    def get_strength(self):
        return self.__strength

    # Getter method for health (encapsulation)
    def get_health(self):
        return self.__health

    # Method to display hero details
    def display_details(self):
        print(f"Hero Name: {self.name}")
        print(f"Alter Ego: {self.alter_ego}")
        print(f"City: {self.city}")
        print(f"Strength: {self.get_strength()}")
        print(f"Health: {self.get_health()}")

    # Method to simulate fighting crime (to be overridden in subclass)
    def fight_crime(self):
        print(f"{self.name} is fighting crime!")


# Child class: Superhero (inherits from Hero)
class Superhero(Hero):
    def __init__(self, name, superpower, alter_ego, city, strength, health, weapon=None):
        # Initialize the parent class (Hero)
        super().__init__(name, alter_ego, city, strength, health)
        self.superpower = superpower  # Unique superpower for Superhero
        self.weapon = weapon  # Optional weapon (e.g., sword, shield, etc.)

    # Method to display superhero details (overrides parent method)
    def display_details(self):
        super().display_details()  # Call the parent method
        print(f"Superpower: {self.superpower}")
        if self.weapon:
            print(f"Weapon: {self.weapon}")
        else:
            print("Weapon: None")

    # Overriding the fight_crime method to add superhero-specific behavior
    def fight_crime(self):
        print(f"{self.name} is fighting crime using their {self.superpower}!")


# Child class: Villain (inherits from Hero) to demonstrate polymorphism
class Villain(Hero):
    def __init__(self, name, alter_ego, city, strength, health, evil_plan):
        # Initialize the parent class (Hero)
        super().__init__(name, alter_ego, city, strength, health)
        self.evil_plan = evil_plan  # Villain's evil plan

    # Overriding the fight_crime method to simulate the villain's actions
    def fight_crime(self):
        print(f"{self.name} is causing chaos in {self.city} with their evil plan: {self.evil_plan}!")


# Create unique objects with inheritance

# Superhero 1: Spider-Man
spider_man = Superhero(
    name="Spider-Man",
    superpower="Web-Slinging",
    alter_ego="Peter Parker",
    city="New York",
    strength=100,
    health=80
)

# Superhero 2: Iron Man
iron_man = Superhero(
    name="Iron Man",
    superpower="Powered Armor",
    alter_ego="Tony Stark",
    city="New York",
    strength=150,
    health=90,
    weapon="Repulsor Rays"
)

# Villain 1: Green Goblin
green_goblin = Villain(
    name="Green Goblin",
    alter_ego="Norman Osborn",
    city="New York",
    strength=120,
    health=70,
    evil_plan="Destroy Spider-Man"
)

# Display details for each character
spider_man.display_details()
iron_man.display_details()
green_goblin.display_details()

# Perform some actions
spider_man.fight_crime()
iron_man.fight_crime()
green_goblin.fight_crime()
