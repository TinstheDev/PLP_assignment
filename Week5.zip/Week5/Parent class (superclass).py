# Parent class (superclass)
class Vehicle:
    def move(self):
        raise NotImplementedError("Subclass must implement this method")

# Child class for Car
class Car(Vehicle):
    def move(self):
        print("Driving 🚗")

# Child class for Plane
class Plane(Vehicle):
    def move(self):
        print("Flying ✈️")

# Child class for Boat
class Boat(Vehicle):
    def move(self):
        print("Sailing 🚤")

# Create instances of each vehicle
car = Car()
plane = Plane()
boat = Boat()

# Call the move() method for each vehicle
car.move()   # Output: Driving 🚗
plane.move() # Output: Flying ✈️
boat.move()  # Output: Sailing 🚤
