# Define the Superhero class
class Superhero:
    def __init__(self, name, superpower, alter_ego):
        self.name = name  # The superhero's name
        self.superpower = superpower  # The superhero's superpower
        self.alter_ego = alter_ego  # The superhero's alter ego

    # Method to display superhero details
    def display_details(self):
        print(f"Superhero Name: {self.name}")
        print(f"Alter Ego: {self.alter_ego}")
        print(f"Superpower: {self.superpower}")

    # Method to perform an action: fight crime
    def fight_crime(self):
        print(f"{self.name} is fighting crime using their {self.superpower}!")

# Create an instance of the Superhero class
hero = Superhero("Spider-Man", "Web-Slinging", "Peter Parker")

# Display superhero details
hero.display_details()

# Make the superhero fight crime
hero.fight_crime()
