# Tuple containing the names of five favorite books
favorite_books = ("1984", "To Kill a Mockingbird", "The Great Gatsby", "Moby-Dick", "Pride and Prejudice")

# Use a for loop to print each book name on a separate line
for book in favorite_books:
    print(book)
