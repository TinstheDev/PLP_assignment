# Create an empty dictionary to store information
person_info = {}

# Ask the user for input and store it in the dictionary
person_info["name"] = input("Enter your name: ")
person_info["age"] = int(input("Enter your age: "))
person_info["favorite_color"] = input("Enter your favorite color: ")

# Print the dictionary
print("\nPerson Information:")
print(person_info)
