# Function to get a set of integers from the user
def get_set_from_user(prompt):
    user_input = input(prompt)
    # Convert the input string to a set of integers
    user_set = set(map(int, user_input.split()))
    return user_set

# Main program
def main():
    print("Enter integers for the first set (separated by spaces):")
    set1 = get_set_from_user("First set: ")
    
    print("Enter integers for the second set (separated by spaces):")
    set2 = get_set_from_user("Second set: ")
    
    # Find the intersection of both sets
    common_elements = set1.intersection(set2)
    
    # Display the result
    print(f"The common elements between the two sets are: {common_elements}")

# Run the main program
if __name__ == "__main__":
    main()
