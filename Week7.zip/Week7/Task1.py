import pandas as pd

# Load the dataset (replace 'your_dataset.csv' with the path to your CSV file)
csv_file = 'your_dataset.csv'  # Update with your CSV file path
df = pd.read_csv(csv_file)

# Display the first few rows of the dataset
print("First few rows of the dataset:")
print(df.head())

# Explore the structure of the dataset
print("\nData Types and Missing Values:")
print(df.info())

# Check for missing values in each column
missing_values = df.isnull().sum()
print("\nMissing values in each column:")
print(missing_values)

# Clean the dataset by filling or dropping missing values
# Option 1: Drop rows with missing values
df_cleaned_drop = df.dropna()

# Option 2: Fill missing values (you can choose a strategy like filling with the mean, median, or mode)
df_cleaned_fill = df.fillna(df.mean())  # For numeric columns, replace NaN with the column mean

# After cleaning, display the first few rows again
print("\nFirst few rows after cleaning (filling missing values with column mean):")
print(df_cleaned_fill.head())
import pandas as pd

# Load the dataset (replace 'your_dataset.csv' with the path to your CSV file)
csv_file = 'your_dataset.csv'  # Update with your CSV file path
df = pd.read_csv(csv_file)

# Display the first few rows of the dataset
print("First few rows of the dataset:")
print(df.head())

# Explore the structure of the dataset
print("\nData Types and Missing Values:")
print(df.info())

# Check for missing values in each column
missing_values = df.isnull().sum()
print("\nMissing values in each column:")
print(missing_values)

# Clean the dataset by filling or dropping missing values
# Option 1: Drop rows with missing values
df_cleaned_drop = df.dropna()

# Option 2: Fill missing values (you can choose a strategy like filling with the mean, median, or mode)
df_cleaned_fill = df.fillna(df.mean())  # For numeric columns, replace NaN with the column mean

# After cleaning, display the first few rows again
print("\nFirst few rows after cleaning (filling missing values with column mean):")
print(df_cleaned_fill.head())
