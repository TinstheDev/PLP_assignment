import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset (replace 'your_dataset.csv' with your CSV file path)
csv_file = 'your_dataset.csv'  # Update with your actual CSV file path
df = pd.read_csv(csv_file)

# Set up the plotting style
sns.set(style="whitegrid")

# 1. Line Chart: Showing trends over time (e.g., sales data over time)
plt.figure(figsize=(10, 6))
df['Date'] = pd.to_datetime(df['Date'])  # Ensure 'Date' is in datetime format
plt.plot(df['Date'], df['Sales'], color='blue', label='Sales', linestyle='-', marker='o')
plt.title('Sales Trend Over Time')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 2. Bar Chart: Comparison of numerical values across categories (e.g., average petal length per species)
plt.figure(figsize=(10, 6))
sns.barplot(x='Species', y='PetalLength', data=df, palette='Set2')
plt.title('Average Petal Length per Species')
plt.xlabel('Species')
plt.ylabel('Average Petal Length')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 3. Histogram: Distribution of a numerical column (e.g., PetalLength)
plt.figure(figsize=(10, 6))
sns.histplot(df['PetalLength'], bins=20, kde=True, color='green')
plt.title('Distribution of Petal Length')
plt.xlabel('Petal Length')
plt.ylabel('Frequency')
plt.tight_layout()
plt.show()

# 4. Scatter Plot: Visualizing the relationship between two numerical columns (e.g., SepalLength vs PetalLength)
plt.figure(figsize=(10, 6))
sns.scatterplot(x='SepalLength', y='PetalLength', data=df, hue='Species', palette='Set1', s=100)
plt.title('Relationship between Sepal Length and Petal Length')
plt.xlabel('Sepal Length')
plt.ylabel('Petal Length')
plt.legend(title='Species')
plt.tight_layout()
plt.show()
