import pandas as pd

# Load the CSV file
csv_file = 'sales_data.csv'  # Replace this with your actual CSV file path
df = pd.read_csv(csv_file)

# Calculate the total revenue
df['Revenue'] = df['Quantity Sold'] * df['Price']  # Assuming 'Quantity Sold' and 'Price' are columns in the CSV
total_revenue = df['Revenue'].sum()

# Find the best-selling product (based on Quantity Sold)
best_selling_product = df.groupby('Product')['Quantity Sold'].sum().idxmax()

# Identify the day with the highest sales
df['Date'] = pd.to_datetime(df['Date'])  # Ensure 'Date' is in datetime format
daily_sales = df.groupby('Date')['Revenue'].sum()
highest_sales_day = daily_sales.idxmax()

# Prepare the results
sales_summary = f"""
Sales Summary:

1. Total Revenue: ${total_revenue:,.2f}
2. Best-Selling Product: {best_selling_product}
3. Day with the Highest Sales: {highest_sales_day.strftime('%Y-%m-%d')}

"""

# Save the results to a new file
with open('sales_summary.txt', 'w') as file:
    file.write(sales_summary)

# Print the insights in a user-friendly format
print(sales_summary)
