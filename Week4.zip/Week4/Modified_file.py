# Read content from the original file
with open('original_file.txt', 'r') as infile:
    content = infile.read()

# Modify the content (example: convert all text to uppercase)
modified_content = content.upper()

# Write the modified content to a new file
with open('modified_file.txt', 'w') as outfile:
    outfile.write(modified_content)

print("File has been read, modified, and written to 'modified_file.txt'.")
