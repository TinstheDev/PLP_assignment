# Ask the user for a filename
filename = input("Enter the filename you want to read: ")

try:
    # Try opening the file and reading its content
    with open(filename, 'r') as file:
        content = file.read()
    print("File content successfully read:")
    print(content)
except FileNotFoundError:
    # Handle the case where the file doesn't exist
    print(f"Error: The file '{filename}' does not exist.")
except PermissionError:
    # Handle the case where the file exists but can't be read due to permission issues
    print(f"Error: You don't have permission to read the file '{filename}'.")
except Exception as e:
    # Handle any other unexpected errors
    print(f"An error occurred: {e}")
